# ShiftPV Helm chart

The chart installs one CSI controller Deployment, one CSI node DaemonSet, the
required provisioner/registrar/liveness sidecars, `CSIDriver`, RBAC, and a
chart-created StorageClass. With `mobility.enabled=true`, the same Controller
Pod also runs the automatic cordon reconciler and HTTPS admission webhook. The
StorageClass is not the cluster default unless explicitly enabled.

Each selected node must already have a writable filesystem mounted at the path
declared by that node's `ShiftPVPool.spec.mountPath`. Paths may differ by node.
The chart never creates, formats, mounts, or repairs those filesystems. ShiftPV
uses each Pool's aggregate reservation limit and current filesystem availability
for new-volume admission, but does not enforce a per-volume write limit.

```bash
helm repo add shiftpv https://cagojeiger.github.io/ShiftPV
helm repo update shiftpv
helm install shiftpv shiftpv/shiftpv \
  --namespace shiftpv-system --create-namespace
```

For repository development, replace `shiftpv/shiftpv` with
`./charts/shiftpv`. Chart versions and component image versions are independent:
the initial chart release was `0.1.0`; its defaults select the separately released
controller and node images. Override those image values together only when
testing an unpublished build.
Published chart packages are gated until both default component image tags expose
`linux/amd64` and `linux/arm64` manifests.

### Kubelet state root

`node.kubeletRootDir` must match the kubelet state root on every node selected by
the Node Plugin DaemonSet. The value controls the CSI plugin socket,
`plugins_registry`, and Pod volume target host paths. A mismatch can leave the CSI
workloads Ready while application Pods remain in `FailedMount` because kubelet and
the Node Plugin are operating on different directories.

The chart default is the conventional `/var/lib/kubelet`. MicroK8s normally uses
`/var/snap/microk8s/common/var/lib/kubelet`, so install it with an explicit value:

```bash
helm install shiftpv shiftpv/shiftpv \
  --namespace shiftpv-system --create-namespace \
  --set node.kubeletRootDir=/var/snap/microk8s/common/var/lib/kubelet \
  --wait
```

For an existing release, pass the same value to `helm upgrade`. The DaemonSet
rollout is sufficient; a Pending Pod recovers on kubelet's normal mount retry once
the Node Plugin uses the correct root. One release has one kubelet root. Standardize
the root or exclude inconsistent nodes with `node.nodeSelector`; a single ShiftPV
release cannot manage mixed kubelet roots.

After installation, explicitly register one `ShiftPVPool` for every participating
node before provisioning volumes. `spec.mountPath` is the runtime authority used
by provisioning helpers, mobility Jobs, and the node plugin on that node.

```yaml
apiVersion: shiftpv.io/v1alpha1
kind: ShiftPVPool
metadata:
  name: storage-worker-a
spec:
  nodeName: worker-a
  mountPath: /mnt/shiftpv
  capacity:
    limit: 500Gi
```

`capacity.limit` is the total requested capacity that ShiftPV may reserve on that
Pool. It is not the disk size and does not reserve space from other processes.
The Node Plugin reports `Mounted`, `Writable`, `CapacityReadable`, and aggregate
`Ready` conditions on the Pool. Wait for readiness before creating PVCs:

```bash
kubectl wait --for=condition=Ready shiftpvpool/storage-worker-a --timeout=2m
```

`poolReadiness.interval` controls the node-local probe and
`poolReadiness.staleAfter` controls how long the Controller trusts its last success.
Set `staleAfter` longer than `interval` with enough allowance for API delays; an
equal or shorter value can make a healthy Pool intermittently unavailable.
The probe creates, syncs, and removes a small temporary file inside the exact Pool
path. A missing path, ordinary unmounted directory, read-only filesystem, permission
failure, failed capacity syscall, outdated generation, or stale probe excludes the
Pool from new provisioning and mobility without changing existing volume ownership.
Pool CRs are cluster operating state; the Helm release does not create or own
them. Because the privileged Node Plugin resolves these paths through a host-root
mount, permission to create or change Pool CRs is security-sensitive and must be
restricted to cluster storage operators. Root (`/`) is rejected.

Automatic mobility is opt-in per workload namespace. Label only namespaces whose
controller-owned, single-PVC workloads follow the current mobility contract.

ShiftPV does not cordon nodes. A cordon is a cluster-wide maintenance signal, so
inspect other workloads and controllers that react to it before changing the node.
Use a dedicated node or an approved maintenance window for mobility validation.

```bash
kubectl label namespace my-workload shiftpv.io/admission=enabled
```

The placement webhook is registered only for labeled namespaces and uses
`failurePolicy=Fail`. In those namespaces it pins a bound ShiftPV volume to its
dynamic owner or applies a Placement Hold while moving. Volumes provisioned outside
the opt-in boundary receive owner-only PV topology and do not depend on the
webhook. The Controller Deployment is fixed to one replica with `Recreate`
strategy so two mobility reconcilers do not overlap.

The Controller creates and reconciles the webhook TLS Secret, mobility
`MutatingWebhookConfiguration`, and lifecycle `ValidatingWebhookConfiguration`;
Helm renders only the stable webhook Service.
It checks once per minute, renews the 90-day serving certificate 30 days before
expiry, and rotates the ten-year CA one year before expiry. TLS handshakes read the
latest in-memory certificate, so renewal does not require a Pod restart. During CA
rotation the old and new CA are temporarily published together before trust is
converged to the new CA. If the Secret is lost, the Controller recovers the old
trust root from the current webhook configuration before switching certificates.
These periods are fixed product contracts rather than chart values.

### Recovery

The source-tree controller checks live Pod and ReplicaSet/StatefulSet template
constraints, destination taints/PV topology, and PDB allowance before locking or
first eviction. A known-ineligible workload is left running and reevaluated;
this does not reserve scheduler capacity or guarantee eventual scheduling.
See the [preflight contract](../../docs/spec/volume-mobility.md#non-disruptive-preflight).
The chart grants read-only `get` on ReplicaSets/StatefulSets and `list` on PDBs.
Use a matching new controller build and apply the CRD including `consumerUID`;
upgrade only with no active moves. Published older binaries do not gain this behavior
from chart/RBAC changes alone.

The source-tree controller supports explicit `ShiftPVMove.spec.recovery=ResumeOwner`
on a Blocked move. It verifies and reopens the current owner; it never rolls a
committed destination back to the stale source. See the
[recovery contract and operating procedure](../../docs/spec/volume-mobility.md#explicit-owner-recovery).
Use a matching controller/helper image when testing this source tree: changing a
chart or CRD alone does not add recovery to an older published binary.

### Upgrade from chart 0.1.3 or earlier

The capacity contract makes `ShiftPVPool.spec.capacity.limit` required. Upgrade
in this order so the new controller never observes the old Pool shape:

1. Apply the target CRDs and explicitly take ownership from the Helm field
   manager. Never delete and recreate a CRD.
2. Add a capacity limit to every existing Pool. Choose a limit no larger than
   the storage allocation that operators intend ShiftPV to reserve on that
   mounted filesystem.
3. Upgrade the Helm release and wait for the Controller and Node Plugin.

Set `TARGET_CHART_VERSION` to the chart being installed from the repository:

```sh
TARGET_CHART_VERSION=x.y.z
helm repo update shiftpv
helm show crds shiftpv/shiftpv --version "${TARGET_CHART_VERSION}" | \
  kubectl apply --server-side --field-manager=shiftpv-crds \
    --force-conflicts -f -
```

For a local chart checkout, the equivalent CRD command is:

```sh
helm show crds ./charts/shiftpv | \
  kubectl apply --server-side --field-manager=shiftpv-crds \
    --force-conflicts -f -
```

Then repair every Pool:

```sh
kubectl get shiftpvpools.shiftpv.io -o name
kubectl patch shiftpvpool <pool-name> --type=merge \
  -p '{"spec":{"capacity":{"limit":"500Gi"}}}'
```

Upgrade using the same values file used to install the release:

```sh
helm upgrade shiftpv shiftpv/shiftpv \
  --version "${TARGET_CHART_VERSION}" \
  --namespace shiftpv-system --values shiftpv-values.yaml --wait
```

For a local chart checkout, use:

```sh
helm upgrade shiftpv ./charts/shiftpv \
  --namespace shiftpv-system --values shiftpv-values.yaml --wait
```

Repeat the patch for every Pool before the Helm upgrade. The new controller
fails closed for provisioning and moves when a Pool has no valid limit. Helm's
`crds/` installation path does not upgrade existing CRDs; `--force-conflicts`
is intentional because the initial Helm installation owns `.spec.versions`.

Do not disable mobility or downgrade to a controller without recovery support while recovery is
in progress; confirm `recoveryPhase=Recovered` and `activeMove` empty first.

Inspect mobility without starting from Controller logs:

```sh
kubectl get shiftpvmoves
kubectl get shiftpvmove <move-name> -o yaml
kubectl get events -n default \
  --field-selector involvedObject.kind=ShiftPVMove,involvedObject.name=<move-name>
```

`Reason`, `message`, `lastTransitionTime`, and `lastProgressTime` distinguish an
automatically retried wait from a terminal `Blocked` move and show the next safe
operator action. Events are emitted only after a phase, reason, or recovery status
change; CR status remains the current source of truth. These timestamps do not
trigger timeout rollback. Cluster-scoped Move events are stored in the `default`
namespace by the Kubernetes Event API.

Changing `mobility.enabled` from `true` to `false` stops the mobility reconciler
but keeps the webhook Service, TLS Secret, HTTPS endpoint, and webhook
configuration. The Controller makes that configuration inert with a match
condition that is always false and changes `failurePolicy` to `Ignore`. This
avoids a Service/configuration deletion-order dependency in Helm and Argo CD.
Re-enabling mobility restores `failurePolicy=Fail` and removes the disabling
condition. The Controller refuses to update same-named certificate resources
without ShiftPV managed labels and expected owner references.

The CSI driver name, topology key, `WaitForFirstConsumer`, `Retain`, RWO
filesystem support, Pool capacity admission, and disabled expansion are fixed
product contracts.

Key configurable values:

| Value | Purpose |
|-------|---------|
| `controller.image.*` | Controller and CSI provisioner-facing binary image |
| `node.image.*` | Node Plugin binary image |
| `mobility.helperImage` | rsync-capable helper image; the Controller image satisfies this contract |
| `mobility.enabled`, `mobility.interval`, `mobility.webhookPort` | event-driven cordon reconciler, bounded safety interval (default `30s`), and admission policy; the HTTPS endpoint remains available while disabled |
| `node.kubeletRootDir` | kubelet state root, normally `/var/lib/kubelet` |
| `node.nodeSelector`, `node.tolerations` | participating node selection |
| `helperPod.image`, `helperPod.timeout`, `helperPod.resources` | node-local directory and capacity helper; a custom image must provide `sh`, `stat`, `du`, `awk`, `mkdir`, and `rm` |
| `poolReadiness.interval`, `poolReadiness.staleAfter` | node-local mount/write/capacity probe interval and Controller freshness limit |
| `lifecycle.uninstallMode` | uninstall owner: `helm` (default, fail fast) or `argocd` (wait and retry) |
| `storageClass.create`, `storageClass.name`, `storageClass.defaultClass` | StorageClass publication and explicit default-class opt-in |
| `controller.resources`, `node.resources`, `sidecars.*.resources` | workload resources |

The fixed `csi.shiftpv.io` name and cluster-scoped resources allow one ShiftPV
Helm release per cluster.

## Uninstall and recovery

The chart runs a fail-closed pre-delete Job and lifecycle validation webhook.
Keep the default `lifecycle.uninstallMode=helm` for Helm-owned releases. Set
`lifecycle.uninstallMode=argocd` in an Argo CD Application so a blocked
PreDelete Job remains active and retries bounded quiesce attempts until storage
dependencies are removed. A normal `helm uninstall`, Argo CD Application deletion, or direct Kubernetes
deletion of protected ShiftPV components is denied
while any ShiftPV PV, PVC using the configured StorageClass, `ShiftPVVolume`, or
non-terminal `ShiftPVMove` exists. Kubernetes API inspection errors also deny
the operation. The webhook protects the labeled CSI Deployment, DaemonSet,
Service, ServiceAccounts, RBAC, StorageClass, and CSIDriver even if an Argo CD
PreDelete hook creation race advances resource pruning. A denial leaves the
release and CSI workloads in place; inspect it with
`kubectl -n <namespace> logs job/<release>-uninstall-guard`.

The guard first creates a five-minute `quiescing` state owned by the current
`CSIDriver` UID. The Controller then rejects new CSI `CreateVolume` calls and
waits for already-running provisioning calls to drain before acknowledging that
specific attempt. Certificate reconciliation is fenced by the same state, so it
cannot recreate lifecycle validation during teardown. Only after acknowledgement
does the guard inspect dependencies, remove lifecycle validation, and change the
state to `granted`. This keeps the remaining Helm or Argo CD deletion independent
of Service and RBAC deletion order. A rapid reinstall gets a new `CSIDriver` UID,
so it cannot inherit the old state.

If inspection or teardown preparation fails, the guard cancels its attempt and
the Controller resumes provisioning and lifecycle validation reconciliation.
Argo CD mode waits five seconds and begins a fresh bounded attempt; Helm mode
returns the failure immediately.
Both `quiescing` and `granted` states expire after five minutes. The lifecycle
webhook itself is read-only: a direct or dry-run DELETE cannot mint permission,
and a direct DELETE is denied even with no storage dependency unless the guard
has completed the quiesce protocol.

For a normal decommission, stop workloads, let Moves become `Succeeded` or
`Blocked`, and explicitly remove the PVC/PV and ShiftPVVolume metadata before
uninstalling. The `Retain` policy means metadata cleanup does not automatically
remove host data.

For emergency recovery, an operator can explicitly remove lifecycle validation
and then bypass the Helm hook with:

```sh
kubectl get validatingwebhookconfiguration \
  -l app.kubernetes.io/managed-by=shiftpv-controller,app.kubernetes.io/component=lifecycle-admission
kubectl delete validatingwebhookconfiguration <name-from-above>
helm uninstall <release> --namespace <namespace> --no-hooks
```

This removes the driver workloads, RBAC, `CSIDriver`, chart-created StorageClass,
and the remaining Controller-managed mobility webhook and TLS Secret through
owner garbage collection. It does not delete CRDs, user PVCs/PVs,
Pool/Volume/Move CRs, dynamically-created reservation ConfigMaps, or data
directories. Existing Pods must not be treated as safely mounted while the node
plugin is absent.

In `argocd` mode the Job is an Argo CD 3.3+ `PreDelete` hook for whole-Application
deletion, while the lifecycle validation webhook is the authoritative deletion barrier.
Argo CD does not run `PreDelete` during ordinary sync pruning. Direct
`kubectl delete` bypasses Helm/Argo hooks but still reaches lifecycle admission
for protected resources. Manage ShiftPV as a dedicated Application and use
Application deletion as its normal removal path.

Reinstall the release into the same namespace, restore the same Pool CRs and
mount paths, wait for controller and node Pods to become ready, and then restart
the user workload. `Retain` also means deleting a PVC leaves its PV and data for
manual recovery instead of calling CSI `DeleteVolume` automatically.
